I did this project so simple and its almost implemented by basic technics, (t.ex i didnt use SCSS)  
I didnt spend enough time on styling because i didnt use bootstrap for long time.
I hope it will be an acceptable project , i have much more better app which i wrote in React, React-native, Next and angular languages.

Thanks :-)